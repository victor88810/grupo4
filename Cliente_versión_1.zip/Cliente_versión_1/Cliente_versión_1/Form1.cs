﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Cliente_versión_1
{
    
    public partial class Form1 : Form
    {
        int conectado = 0;
        int sesion = 0;
        Socket server;
        string username;
        string password;
        string userensesion;
        string rusername, rpassword;
        bool finalizado = false;

        public void SetUsername(string usuario)
        {
            rusername = usuario;
        }
        public void SetPassword(string contraseña)
        {
            rpassword = contraseña;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Conectar_Click(object sender, EventArgs e)
        {
            if (conectado == 0)
            {
                //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
                //al que deseamos conectarnos
                IPAddress direc = IPAddress.Parse("192.168.56.101");
                IPEndPoint ipep = new IPEndPoint(direc, 9250);


                //Creamos el socket 
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                try
                {
                    server.Connect(ipep);//Intentamos conectar el socket
                    this.BackColor = Color.Green;
                    MessageBox.Show("Conectado");
                    conectado = 1;

                }
                catch (SocketException ex)
                {
                    //Si hay excepcion imprimimos error y salimos del programa con return 
                    MessageBox.Show("No he podido conectar con el servidor");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Ya estas conectado");
            }
        }

        private void Desconectar_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
            conectado = 0;

        }

        private void Registro_Click(object sender, EventArgs e)
        {
            if (conectado == 0)
            {
                MessageBox.Show("Conectese Primero");
            }
            else
            {
                while (finalizado == false)
                {
                    Registro registro = new Registro();
                    registro.eventousername += new Registro.DelegadoUsername(SetUsername);
                    registro.eventopassword += new Registro.DelegadoPassword(SetPassword);
                    registro.ShowDialog();

                    string mensaje = "1/" + rusername + "/" + rpassword;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                    byte[] msg2 = new byte[500];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    int registrado = Convert.ToInt32(mensaje);
                    if (registrado == 1)
                    {
                        MessageBox.Show("El nombre de usuario ya esta en uso");
                    }
                    else
                    {
                        MessageBox.Show("Usuario registrado correctamente");
                        finalizado = true;
                    }

                }
            }
        }

        private void Iniciar_sesion_Click(object sender, EventArgs e)
        {
            if (conectado == 0)
            {
                MessageBox.Show("Conectese Primero");
            }
            else
            {
                username = nombre.Text;
                password = contraseña.Text;
                if (username == "" || password == "")
                {
                    MessageBox.Show("Indique los datos");
                }
                else
                {
                    string mensaje = "2/" + username + "/" + password;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    byte[] msg2 = new byte[500];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                    int registrado = Convert.ToInt32(mensaje);
                    if (registrado == 1)
                    {
                        MessageBox.Show("Sesión iniciada correctamente");
                        userensesion = username;
                    }
                    else
                    {
                        MessageBox.Show("Datos incorrectos");
                        finalizado = true;
                    }
                }
            }
        }

        private void SumarmeFondos_Click_1(object sender, EventArgs e)
        {
            string mensaje = "4/" + userensesion;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show("Tus Fondos son:" + mensaje);
        }

        private void Ranking_Click_1(object sender, EventArgs e)
        {
            string mensaje = "5/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show("El ranking es " + mensaje);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mensaje = "4/" + userensesion;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2);
            MessageBox.Show("Tus Fondos son: " + mensaje + "\n");
        }


    }
}
